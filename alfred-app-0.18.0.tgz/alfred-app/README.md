# alfred-app

A Helm chart for Alfred, the Slack support manager

**Homepage:** <https://github.com/giantswarm/alfred-app>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Giant Swarm applications team |  | <https://github.com/giantswarm/alfred-app> |

## Source Code

* <https://github.com/giantswarm/alfred-app-app>
* <https://raw.githubusercontent.com/giantswarm/alfred-app/v[[ .Version ]]/README.md>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| replicaCount | int | `1` |  |
| slack.reportingChannel | string | `"C02EVLE9W"` |  |
| slack.signingSecret | string | `"dummy"` |  |
| slack.slackToken | string | `"dummy"` |  |
| pagerduty.token | string | `"dummy"` |  |
| pagerduty.morningShift.scheduleID | string | `"PPE2Z40"` |  |
| pagerduty.morningShift.probeHour | int | `10` |  |
| pagerduty.afternoonShift.scheduleID | string | `"PTQQZGQ"` |  |
| pagerduty.afternoonShift.probeHour | int | `15` |  |
| image.registry | string | `"gsociprivate.azurecr.io"` |  |
| image.name | string | `"giantswarm/alfred"` |  |
| image.pullPolicy | string | `"Always"` |  |
| image.tag | string | `""` |  |
| imagePullSecrets | list | `[]` |  |
| nameOverride | string | `""` |  |
| fullnameOverride | string | `""` |  |
| global.podSecurityStandards.enforced | bool | `false` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.name | string | `nil` |  |
| baseDomain | string | `"operations.awsprod.gigantic.io"` |  |
| podSecurityContext.fsGroup | int | `2000` |  |
| podSecurityContext.runAsGroup | int | `3000` |  |
| podSecurityContext.runAsUser | int | `1000` |  |
| podSecurityContext.runAsNonRoot | bool | `true` |  |
| securityContext.allowPrivilegeEscalation | bool | `false` |  |
| securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| securityContext.privileged | bool | `false` |  |
| securityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| service.type | string | `"ClusterIP"` |  |
| service.port | int | `8080` |  |
| resources.limits.cpu | string | `"250m"` |  |
| resources.limits.memory | string | `"256Mi"` |  |
| resources.requests.cpu | string | `"250m"` |  |
| resources.requests.memory | string | `"256Mi"` |  |
| nodeSelector | object | `{}` |  |
| tolerations | list | `[]` |  |
| affinity | object | `{}` |  |
| timeZone | string | `"Europe/Berlin"` |  |
| prometheusRule.enabled | bool | `true` |  |
| prometheusRule.team | string | `"planeteers"` |  |
| prometheusRule.maxDaysWithoutSuccess | int | `4` |  |
| reporter[0].name | string | `"get-hanging-threads"` |  |
| reporter[0].schedule | string | `"1 9 * * 1-5"` |  |
| reporter[0].url | string | `"http://alfred-app:8080/get-hanging-threads"` |  |
| reporter[1].name | string | `"who-is-on-support-am"` |  |
| reporter[1].schedule | string | `"0 9 * * 1-5"` |  |
| reporter[1].url | string | `"http://alfred-app:8080/who-is-on-support"` |  |
| reporter[2].name | string | `"who-is-on-support-pm"` |  |
| reporter[2].schedule | string | `"31 13 * * 1-5"` |  |
| reporter[2].url | string | `"http://alfred-app:8080/who-is-on-support"` |  |
| reporter[3].name | string | `"remind-tomorrow-shift-am"` |  |
| reporter[3].schedule | string | `"30 8 * * 1-5"` |  |
| reporter[3].url | string | `"http://alfred-app:8080/remind-tomorrow-shift?shift=morning"` |  |
| reporter[4].name | string | `"remind-tomorrow-shift-pm"` |  |
| reporter[4].schedule | string | `"0 14 * * 1-5"` |  |
| reporter[4].url | string | `"http://alfred-app:8080/remind-tomorrow-shift?shift=afternoon"` |  |
| reporter[5].name | string | `"report-eob"` |  |
| reporter[5].schedule | string | `"45 17 * * 1-5"` |  |
| reporter[5].url | string | `"http://alfred-app:8080/report"` |  |
| cortex.url | string | `""` |  |
| cortex.username | string | `""` |  |
| cortex.password | string | `""` |  |
