# alfred-app

A Helm chart for Alfred, the Slack support manager

**Homepage:** <https://github.com/giantswarm/alfred-app>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Giant Swarm applications team |  | <https://github.com/giantswarm/alfred-app> |

## Source Code

* <https://github.com/giantswarm/alfred-app-app>
* <https://raw.githubusercontent.com/giantswarm/alfred-app/v[[ .Version ]]/README.md>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| replicaCount | int | `1` |  |
| slack.reportingChannel | string | `"C02EVLE9W"` |  |
| slack.signingSecret | string | `"dummy"` |  |
| slack.slackToken | string | `"dummy"` |  |
| slack.excludedChannels | list | `["support-alfred-test","support-noise"]` | Support channels Alfred ignores entirely: channels used for tests, and channels of customers that are not onboarded yet. They look exactly like a live customer channel, so only this list can tell them apart. Full channel names, with or without the leading "#", e.g. "support-acme". |
| pagerduty.token | string | `"dummy"` |  |
| pagerduty.morningShift.scheduleID | string | `"PPE2Z40"` |  |
| pagerduty.morningShift.probeHour | int | `10` |  |
| pagerduty.afternoonShift.scheduleID | string | `"PTQQZGQ"` |  |
| pagerduty.afternoonShift.probeHour | int | `15` |  |
| image.registry | string | `"gsociprivate.azurecr.io"` |  |
| image.name | string | `"giantswarm/alfred"` |  |
| image.pullPolicy | string | `"Always"` |  |
| image.tag | string | `""` |  |
| imagePullSecrets | list | `[]` |  |
| nameOverride | string | `""` |  |
| fullnameOverride | string | `""` |  |
| global.podSecurityStandards.enforced | bool | `false` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.name | string | `nil` |  |
| baseDomain | string | `"operations.awsprod.gigantic.io"` |  |
| podSecurityContext.fsGroup | int | `2000` |  |
| podSecurityContext.runAsGroup | int | `3000` |  |
| podSecurityContext.runAsUser | int | `1000` |  |
| podSecurityContext.runAsNonRoot | bool | `true` |  |
| securityContext.allowPrivilegeEscalation | bool | `false` |  |
| securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| securityContext.privileged | bool | `false` |  |
| securityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| service.type | string | `"ClusterIP"` |  |
| service.port | int | `8080` |  |
| resources.limits.cpu | string | `"250m"` |  |
| resources.limits.memory | string | `"256Mi"` |  |
| resources.limits.ephemeral-storage | string | `"256Mi"` | Ephemeral storage limit. The app itself opens nothing on disk and logs to stdout, so this covers the runtime's rotated container logs. |
| resources.requests.cpu | string | `"250m"` |  |
| resources.requests.memory | string | `"256Mi"` |  |
| resources.requests.ephemeral-storage | string | `"64Mi"` | Ephemeral storage request. Declared so the pod-level budget, which kubelet sums from the containers, is chosen here rather than inherited from the sidecar alone. |
| alloy.image | object | `{"name":"giantswarm/alloy","registry":"gsoci.azurecr.io","tag":"v1.19.2"}` | Sidecar image. Multi-arch, so it does not constrain `architecture`. |
| alloy.resources | object | `{"limits":{"cpu":"250m","ephemeral-storage":"512Mi","memory":"250Mi"},"requests":{"cpu":"250m","ephemeral-storage":"64Mi","memory":"250Mi"}}` | Resources for the `alloy` metrics sidecar, which scrapes the app and ships the samples to Grafana Cloud. |
| alloy.resources.limits.ephemeral-storage | string | `"512Mi"` | Ephemeral storage limit for the sidecar. Deliberate headroom over an already time-bounded WAL: Alloy truncates it every 2h by default and keeps at most 8h of samples, so it cannot grow without end. |
| alloy.resources.requests.ephemeral-storage | string | `"64Mi"` | Ephemeral storage request for the sidecar. Required by the `require-emptydir-requests-and-limits` policy, because this is the container that mounts the `alloy-storage` `emptyDir`. The volume itself is bounded by its own `sizeLimit`, not by this container limit: kubelet charges an `emptyDir` to the pod, while a container's ephemeral-storage limit covers only its writable layer and logs. |
| architecture | string | `""` | Target CPU architecture for the deployment and the reporter CronJobs. Empty imposes no constraint. `arm64` pins them to arm64 nodes, adding both the `kubernetes.io/arch` node selector and the toleration for the `kubernetes.io/arch=arm64:NoSchedule` taint that Giant Swarm arm64 node pools carry. Both are required, so this single value sets both. Every image in the pod must be multi-arch. Both are: the app image and the `alloy` sidecar. Do not also constrain `kubernetes.io/arch` through a `nodeAffinity`: that is ANDed with the node selector and is not visible to this value, so a contradicting one leaves the pod Pending. |
| nodeSelector | object | `{}` | Node selector for pod scheduling. Merged with `architecture`. Pinning to arm64 here rather than through `architecture` also adds the arm64 taint toleration, so either route is safe. A value that contradicts `architecture` fails the render. |
| tolerations | list | `[]` | Tolerations for pod scheduling. Merged with the toleration that `architecture: arm64` adds. |
| affinity | object | `{}` | Affinity rules for pod scheduling. |
| timeZone | string | `"Europe/Berlin"` |  |
| prometheusRule.enabled | bool | `true` |  |
| prometheusRule.team | string | `"planeteers"` |  |
| prometheusRule.maxDaysWithoutSuccess | int | `4` |  |
| reporter[0].name | string | `"get-hanging-threads"` |  |
| reporter[0].schedule | string | `"1 9 * * 1-5"` |  |
| reporter[0].url | string | `"http://alfred-app:8080/get-hanging-threads"` |  |
| reporter[1].name | string | `"who-is-on-support-am"` |  |
| reporter[1].schedule | string | `"0 9 * * 1-5"` |  |
| reporter[1].url | string | `"http://alfred-app:8080/who-is-on-support"` |  |
| reporter[2].name | string | `"who-is-on-support-pm"` |  |
| reporter[2].schedule | string | `"31 13 * * 1-5"` |  |
| reporter[2].url | string | `"http://alfred-app:8080/who-is-on-support?openThreads=true"` |  |
| reporter[3].name | string | `"remind-tomorrow-shift-am"` |  |
| reporter[3].schedule | string | `"30 8 * * 1-5"` |  |
| reporter[3].url | string | `"http://alfred-app:8080/remind-tomorrow-shift?shift=morning"` |  |
| reporter[4].name | string | `"remind-tomorrow-shift-pm"` |  |
| reporter[4].schedule | string | `"0 14 * * 1-5"` |  |
| reporter[4].url | string | `"http://alfred-app:8080/remind-tomorrow-shift?shift=afternoon"` |  |
| reporter[5].name | string | `"report-eob"` |  |
| reporter[5].schedule | string | `"45 17 * * 1-5"` |  |
| reporter[5].url | string | `"http://alfred-app:8080/report"` |  |
| cortex.url | string | `""` | remote_write endpoint for the `alloy` sidecar. Needs a scheme. An empty value is accepted at startup and surfaces only once samples exist, as a per-batch warn log (`unsupported protocol scheme ""`), so the pod stays Ready and the metrics go undelivered rather than the deployment failing. |
| cortex.username | string | `""` | Basic auth username for `url`. |
| cortex.password | string | `""` | Basic auth password for `url`. |
